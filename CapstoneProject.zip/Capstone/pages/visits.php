<?php
include("../includes/navbar.php");

$imageErr = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $mbFileSize = $_FILES["fileToUpload"]["size"] / 1000000;
      if ($mbFileSize > 10) {
          $imageErr = "Your file is too large. Max file size is 10MB. Yours was $mbFileSize MB";
      }

      $location = clean_input($_POST["location"]);
      $dateVisited = clean_input($_POST["dateVisited"]);
      $recommendations = clean_input($_POST["recommendations"]);

      $primaryImage = file_get_contents($_FILES['fileToUpload']['tmp_name']); 
      $imageTitle = htmlspecialchars($_FILES["fileToUpload"]["name"]);
     

      if (!empty($location) && !empty($recommendations) && !empty($dateVisited) ) {
        //$itemId = $_SESSION['itemID'];
    
        $itemInfo = array(
          "visitId" => "",
          "location" => $location,
          
          "dateVisited" => $dateVisited,
          "primaryImage" => $primaryImage,
        "imageTitle" => $imageTitle,
        "recommendations" => $recommendations
        );

        $article = new visit($conn, $itemInfo);
        $article->createItem(); 
        header("Location:SplashPage.php");
    }
}
?>


<style>
    .error {color: #FF0000;}
    .myForm{margin-top: 50px; width: 800px; height: 600px; background-color: #ADADC9; padding: 30px 30px; color: black; border: 3px outset white; text-shadow: 2px 2px lightblue; border-radius: 25px;}
    input[type=text]{background-color:  #E6E6FA; border: white; border-radius: 10px; height: 40px; text-align: center;}
    input[type=submit]{margin-left: 320px; background-color:  #7852A9; cursor: pointer; border: white; border-radius: 10px; padding: 10px 30px; font-weight: bold; font-size: 15px; }
     
    
</style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-10 col-lg-8 col-xl-7">
      <form class="myForm" enctype="multipart/form-data"  method="post" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <div class="form-group">
          <label for="location">location</label>
          <span class="error">*</span><br>
          <input type="text" class="form-control" name="location" id="location" required>
          <label for="dateVisited">Date</label>
          <span class="error">*<br>
          <input type="text" class="form-control" name="dateVisited" id="dateVisited" required><br></br>
        </div>

        <div class="form-group">
            <label for="fileToUpload">Select image to upload:</label>
            <span class="error">* <?php echo $imageErr;?></span><br></br>
          
            <input type="file" name="fileToUpload" id="fileToUpload" ><br></br>
           
        </div>

        <div class="form-group">
          <label for="recommendations">Recommendations</label>
          <span class="error">*<br>
          <textarea rows="5" class="form-control" name="recommendations" id="recommendations" required></textarea><br></br>
        </div>
       
        <input type="submit" class="btn btn-primary" value="Submit">
    </form>    
    </div>
  </div>
</div>

        
