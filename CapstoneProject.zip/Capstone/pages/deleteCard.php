<?php
include("../includes/navbar.php");

$visitId = $_GET['deletevisitId'];

if (isset($visitId)) {
  try {
    $article = visit::getArticleById($conn, $visitId);
  } catch(Exception) {
    header("Location: 404.php");
  }
} else {
  header("Location: 404.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $article->deleteArticle();
  header("Location: SplashPage.php");
}
?>

<div class="container">
  <div class="row justify-content-center text-center">
    <div class="col-md-10 col-lg-8">
      <form method="post" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="submit">Are you sure you want to delete this visit?</label>
        <input type="submit" class="btn btn-danger" value="Delete">
      </form>
    </div>
    <div class="col-md-10 col-lg-8">
      <a href="SplashPage.php" class="btn btn-success">Cancel</a>
    </div>
  </div>
</div>