<?php
  include("../includes/navbar.php");
  $data = visit::getAllFromDb($conn, 20);

  
  ?>

<style>
  body{
    background-image: url("../images/explore.jpg");
    
  }
</style>

<?php
  if (isset($_SESSION['userName'])) {
?>

<div class='container'>
    <div class="row">
        <div class="col-12 col-lg-6 offset-lg-3">
            <h1>Hello <?php echo $_SESSION['userName'] ?></h1></br>
            <a class="btn btn-primary" href="visits.php">Add Your Recent Trip Here</a>
        </div>
    </div>
</div>


<?php
} else {
    header("Location: ../pages/home.php");
}
?>

<?php
include("../includes/3x3Cards.php");
?>

  

  
