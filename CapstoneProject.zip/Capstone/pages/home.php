<?php
  include("../includes/navbar.php");
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>travelling around the world</title>
    
    <link rel="stylesheet" href="../includes/myStyle.css"> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body>
    
<div id="myCarousel" class="carousel slide" data-bs-ride="carousel">

    <div class="carousel-inner">
    <div class="carousel-item active">
    <img src="../images/soire.JPG" class="d-block w-100" alt="">
    <div class="container">
     
        <h1>As We Go</h1>
        <h4>Africe, Australia, America, We share places and real experience from every where!</h4> 
        <br></br>
        <button type="button" id="signButton"><a style="text-decoration:none" href="../pages/signUp.php">Sign Up</a></button>
        </div>
    </div>
        <div class="carousel-item">
        <img src="../images/map.JPG" class="d-block w-100" alt="">
        </div>

        <div class="carousel-item">
        <img src="../images/travel.JPG" class="d-block w-100" alt="">
        </div>

<button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>

  </div> 
    
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
 
 

<br></br>

 <hr></hr>
  <div class="infoDiv">

  <div class="a"> Customer Care <br>
    <span>
    <a> Contact Us </a>
    <p> 614-809-0116 </p> 
</span>
  </div>
  
  <div class="a"> Follow Us 
  <div>
    <span class="d">
    <a href="https://www.facebook.com/profile.php?id=100015470291812"><img src="../images/facebook.jpg" width="80px" height="25px"></a></span><br>
    <pre></pre>
    <span class="d">
    <a href="https://www.pinterest.com/saralolli/_saved/"><img src="../images/pinterest.png" width="25px" height="25px"></a></span>
  </div>
  </div>
      
  <div class="a">  <a href="../pages/aboutPage.php">About Us</a>  </div>
  </div>


</body>
</html>

