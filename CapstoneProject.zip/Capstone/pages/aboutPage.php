<?php
  include("../includes/navbar.php");
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="../includes/myStyle.css"> 
    </head>
  <body>

  <main>
  <h1> As We Go </h1>
  <h4> Our Story </h4> 
<p> People often inquire about my background, but they fail to identify the country, let alone its location on the continent.</br> 
  Moreover, my passion for traveling has fueled my desire to create a platform where users can create accounts </br>
  and share their travel experiences through pictures, comments, and locations, allowing others to benefit from their adventures.</p>

  <h4> Our Mission </h4>
<p>Our mission is to inspire and empower people to explore the world and create their own unforgettable travel adventures.</br> 
  We believe that travel has the power to broaden our perspectives, connect us with other cultures, and make the world a better place.</br> 
  We strive to provide the best travel resources, tips, and advice to help you plan your dream trip.</p>
		


<h4> Became One Of Us! </h4>
<p> Our users can utilize this space to share their global travel experiences. </br>
  Here, you can explore different destinations, browse through pictures and read real-life accounts to assist in planning your own journey. </br>
  Even if you haven't traveled yet, this platform can provide you with inspiration! </p> 
  <ul>
				<li class="b"><img src="../images/team-member-1.jpg" alt="Team Member 1" width="180px" height="150px"><p>Jane Doe</p></li>
				<li class="b"><img src="../images/team-member-2.jpg" alt="Team Member 2" width="180px" height="150px"><p>John Smith</p></li>
				<li class="b"><img src="../images/team-member-3.jpg" alt="Team Member 3" width="180px" height="150px"><p>Shan Lee</p></li>
				<li class="b"><img src="../images/team-member-4.jpg" alt="Team Member 4"width="180px" height="150px"><p>David Brown</p></li>
	</ul>

  </main>
<footer>
		<p>&copy; AsWeGo.com 2023. All Rights Reserved.</p>
	</footer>
</body>