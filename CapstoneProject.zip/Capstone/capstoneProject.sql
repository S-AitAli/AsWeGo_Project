DROP DATABASE IF EXISTS finalProjectCapstoneSara;
CREATE DATABASE finalProjectCapstoneSara;

USE finalProjectCapstoneSara;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
userID INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
fullName VARCHAR(255),
userName VARCHAR(255),
userPassword VARCHAR(255)
);

DROP TABLE IF EXISTS visitedLocations;
CREATE TABLE visitedLocations(
visitId INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
location VARCHAR(255),
dateVisited DATE,
primaryImage MEDIUMBLOB,
imageTitle VARCHAR(255),
recommendations VARCHAR(1000)
);

INSERT INTO visitedLocations(location, dateVisited, primaryImage, imageTitle, recommendations)
VALUES
("Florida", "2021-01-20", LOAD_FILE('C:/xampp/htdocs/sara_aitali/Capstone/images/miami.jpg'), 'Miami Beach', "If you're planning a trip to Florida, I would highly recommend exploring the state's diverse range of attractions and activities. From the stunning beaches and crystal-clear waters of the Gulf of Mexico and the Atlantic Ocean, to the world-class theme parks and natural parks, there is something for everyone in Florida."),
("Columbus", "2019-04-20", LOAD_FILE('C:/xampp/htdocs/sara_aitali/Capstone/images/columbus.jpg'), 'Columbus', "One must-visit destination is Cleveland, home to the Rock and Roll Hall of Fame, the Cleveland Museum of Art, and the Cleveland Metroparks Zoo. Columbus, the state capital, is another great spot to explore, with attractions such as the Columbus Zoo and Aquarium, the Ohio Statehouse, and the Center of Science and Industry."),
("Algeria", "2019-04-20", LOAD_FILE('C:/xampp/htdocs/sara_aitali/Capstone/images/bejaia.jpg'), 'Columbus', "Béjaïa is a coastal city located in the north-eastern region of Algeria, on the Mediterranean Sea. It is the largest city in the Kabylie region and is known for its beautiful scenery, stunning beaches, and historical landmarks. Béjaïa has a rich history, having been settled by the Phoenicians, Romans, Arabs, and Ottomans over the centuries. Today, it is a bustling port city and a popular tourist destination, attracting visitors from around the world to its beaches, markets, and cultural events. Its vibrant mix of modern amenities and ancient traditions make it a unique and fascinating place to visit.");

select * from users;
select * from visitedLocations;