
<?php
class visit {
    // parameters
    public $conn;
    public $visitId;
    public $location;
    public $dateVisited;
    public $primaryImage;
    public $imageTitle;
    public $recommendations;
   

    function __construct($conn, $itemInfo) {
        $this->conn = $conn;
        $this->visitId = $itemInfo['visitId'];
        $this->location = $itemInfo['location'];
        $this->dateVisited = $itemInfo['dateVisited'];
        //$this->userID = $itemInfo['userID'];
        $this->primaryImage = $itemInfo['primaryImage'];
        $this->imageTitle = $itemInfo['imageTitle'];
        $this->recommendations = $itemInfo['recommendations'];
        
       
    }

    function __destruct() { }

    static function getItemFromDb($conn, $itemID) {
        $selectItems = "SELECT * FROM visitedLocations
        WHERE visitedLocations.visitId=:visitId";
        $stmt = $conn->prepare($selectItems);
        $stmt->bindParam(':visitId', $visitId, PDO::PARAM_INT);
        //$stmt->bindParam(':numItems', $numItems, PDO::PARAM_INT);
        $stmt->execute();
       
        $articleList = array();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        foreach($stmt->fetchAll() as $listRow) {
            $article = new visit($conn, $listRow);
            $articleList[] = $article;
        }
    
        return $articleList;
    }

    static function getAllFromDb($conn, $number) {
        $selectItems = "SELECT * FROM visitedLocations
        LIMIT :number";
        $stmt = $conn->prepare($selectItems);
        $stmt->bindParam(':number', $number, PDO::PARAM_INT);
        $stmt->execute();
       
        $articleList = array();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        foreach($stmt->fetchAll() as $listRow) {
            $article = new visit($conn, $listRow);
            $articleList[] = $article;
        }
    
        return $articleList;
    }

    function createItem() {
        $insert = "INSERT INTO visitedLocations
            (location, dateVisited, primaryImage, imageTitle, recommendations)
            VALUES
            (:location, :dateVisited, :primaryImage, :imageTitle, :recommendations)";
        $stmt = $this->conn->prepare($insert);
        $stmt->bindParam(':location', $this->location);
        $stmt->bindParam(':dateVisited', $this->dateVisited);
       // $stmt->bindParam(':userID', $this->userID);
        $stmt->bindParam(':primaryImage', $this->primaryImage);
        $stmt->bindParam(':imageTitle', $this->imageTitle);
        $stmt->bindParam(':recommendations', $this->recommendations);
        $stmt->execute();
    }

    static function getArticleById($conn, $visitId) {
        $selectVisits = "SELECT * FROM visitedLocations
        
        WHERE visitedLocations.visitId=:visitId";
        $stmt = $conn->prepare($selectVisits);
        $stmt->bindParam(':visitId', $visitId, PDO::PARAM_INT);
        $stmt->execute();
   
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        foreach($stmt->fetchAll() as $listRow) {
            $visit = new visit($conn, $listRow);
        }
        return $visit;
    }


    function deleteArticle(){
        $delet = "DELETE FROM visitedLocations
        WHERE visitId=:visitId";
        $stmt = $this->conn->prepare($delet);
        $stmt->bindParam(':visitId', $this->visitId, PDO::PARAM_INT);
        $stmt->execute();
    }
    
}
?>