<?php
        $data = visit::getAllFromDb($conn, 20); 
          foreach ($data as $article) {
        $visitId = $article->visitId;
      
  ?>  

<style>
  .col-md-3{
margin-left: 100px;
  }

  .itemCard{
    width: 300px;
   border: 1px solid #eaeaec;
   margin: 50px 20px 10px 20px;
   padding: 10px;
   text-align: center;
   background-color: #efefef;
   border-radius: 15px;
  }
</style>

  <div class="col-md-3" style="display: inline-block">
              <div class="itemCard">
        <?php if (!empty($article->primaryImage)) { ?>
                <img src='data:image/jpeg;base64,<?php echo base64_encode( $article->primaryImage )?>' class="card-img-top"/>
              <?php } ?>
        <div class= "card-block">
        
            <span><?php echo $article->location ?></span>
        </br>
            <span><?php echo  $article->dateVisited ?></span>
        </br>
            <span><?php echo $article->recommendations ?></span>
        </div>
        </br> <div class="col-12 col-md-5 text-end">
              <a class='btn btn-danger' href='deleteCard.php?deletevisitId=<?php echo $visitId ?>'>Delete</a>
            </div>
    </div>
      </div>
     <?php
        }
    ?>




